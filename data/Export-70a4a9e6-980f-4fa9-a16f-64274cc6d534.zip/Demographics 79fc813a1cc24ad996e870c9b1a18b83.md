# Demographics

[Races](Races%200137f73abd204c52a2ff4dc8075520b0.md)

- Telaria: Population approximately 500,000
- Eryndor: Population approximately 400,000
- Zephyr: Population approximately 300,000
- Avandor: Population approximately 250,000
- Kytherian Republic: Population approximately 1,000,000
- Frostfall: Population approximately 200,000
- Ironforge: Population approximately 150,000
- Shadowdale: Population approximately 100,000